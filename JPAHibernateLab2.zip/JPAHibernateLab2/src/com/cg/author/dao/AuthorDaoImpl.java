package com.cg.author.dao;

import javax.persistence.EntityManager;

import com.cg.author.entities.Author;
public class AuthorDaoImpl implements Authordao{
	private EntityManager entityManager;

	public AuthorDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}
	@Override
	public void addAuthorDao(Author author) {

		entityManager.persist(author);
	}

	@Override
	public void beginTransaction() {

		entityManager.getTransaction().begin();
	}

	@Override
	public void commitTransaction() {

		entityManager.getTransaction().commit();
	}
	@Override
	public Author findById(int id1) {
		Author author=entityManager.find(Author.class, id1);
		return author;
		
		
	}
	@Override
	public void updateDetails(Author author) {
		
		entityManager.merge(author);
	}
	@Override
	public void removeDetails(Author author) {
		entityManager.remove(author);
		
	}
	

}
