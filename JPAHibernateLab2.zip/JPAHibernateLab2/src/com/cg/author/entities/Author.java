package com.cg.author.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Author055")
public class Author {
@Id
@Column(name="AUTH_ID",length=10)
@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="author_seq")
@SequenceGenerator(name="author_seq", sequenceName="authorsequence",allocationSize=100)
int authorId;
@Column(name="FIRST_NAME",length=20)
String firstName;
@Column(name="LAST_NAME",length=20)
String lastName;
@Column(name="PHN_NO",length=10)
String phnNo;
public int getAuthorId() {
	return authorId;
}
public void setAuthorId(int authorId) {
	this.authorId = authorId;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getPhnNo() {
	return phnNo;
}
public void setPhnNo(String phnNo) {
	this.phnNo = phnNo;
}
	
}
