package com.cg.author.ui;

import com.cg.author.dao.AuthorDaoImpl;
import com.cg.author.dao.Authordao;
import com.cg.author.entities.Author;
import com.cg.author.service.AuthorService;

public class AuthorServiceImpl implements AuthorService {
private static Authordao dao=null;
static {
	dao=new AuthorDaoImpl();
}
	@Override
	public void addAuthor(Author author) {
	
		dao.beginTransaction();
		dao.addAuthorDao(author);
		dao.commitTransaction();
	}
	@Override
	public Author findById(int id1) {
	
	return dao.findById(id1);
		
	}
	@Override
	public void updateDetails(Author author) {
		dao.beginTransaction();
		dao.updateDetails(author);
		dao.commitTransaction();
	}
	@Override
	public void removeAuthor(Author author) {
		
		dao.beginTransaction();
		dao.removeDetails(author);
		dao.commitTransaction();
	}

}
