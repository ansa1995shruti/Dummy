package com.cg.walletapp.service;

import java.math.BigDecimal;

import java.time.LocalDateTime;
import java.util.List;


import com.cg.walletapp.bean.Customer;
import com.cg.walletapp.dao.IWalletDao;
import com.cg.walletapp.dao.WalletDaoImpl;
import com.cg.walletapp.exception.IWalletException;
import com.cg.walletapp.exception.WalletException;

public class WalletService implements IWalletService {
	IWalletDao dao = new WalletDaoImpl();

	public void addAccount(Customer customer) throws WalletException {

		dao.addAccountDao(customer);
	}

	public boolean checkMobno(String mobnum) throws WalletException {
		return dao.checkMobno(mobnum);
	}

	public Customer showBalance(String mobnum) throws WalletException {
		Customer customerinfo = dao.findOne(mobnum);

		return customerinfo;

	}

	public BigDecimal transferFund(String mobnum, String mobnumber, BigDecimal transferamount) throws WalletException {

		Customer customerinfo = dao.findOne(mobnum);
		Customer customerinfo2 = dao.findOne(mobnumber);
		BigDecimal amount1 = customerinfo.getWalletBalance();
		BigDecimal amount2 = customerinfo2.getWalletBalance();
		amount1 = amount1.subtract(transferamount);
		customerinfo.setWalletBalance(amount1);
		dao.updateBalance(mobnum, amount1);
		BigDecimal finalamount = amount2.add(transferamount);
		customerinfo2.setWalletBalance(finalamount);
		dao.updateBalance(mobnumber,finalamount);
		dao.addTransactions(mobnum,"FundTransfered " + transferamount + " From :- " + mobnum + " to- " + mobnumber + " at n-  "
				+ LocalDateTime.now());
		return customerinfo.getWalletBalance();
	}

	public BigDecimal depositBalance(String mobnum, BigDecimal amount1) throws WalletException {
		Customer customerinfo = dao.findOne(mobnum);
		BigDecimal amountnew = customerinfo.getWalletBalance();
		BigDecimal amountdeposit = amountnew.add(amount1);
		customerinfo.setWalletBalance(amountdeposit);
		dao.updateBalance(mobnum, amountdeposit);
		dao.addTransactions(mobnum,"Amount Depsoited " + amount1 + " at - " + LocalDateTime.now());
		return customerinfo.getWalletBalance();

	}

	public BigDecimal withdrawal(String mobnum, BigDecimal amount2) throws WalletException {

		Customer customerinfo = dao.findOne(mobnum);
		BigDecimal amountnew1 = customerinfo.getWalletBalance();
		BigDecimal amountwithdraw = amountnew1.subtract(amount2);
		customerinfo.setWalletBalance(amountwithdraw);
		dao.updateBalance(mobnum, amountwithdraw);
		dao.addTransactions(mobnum,"Amount WithDrawn " + amount2 + " at - " + LocalDateTime.now());
		return customerinfo.getWalletBalance();

	}

	public boolean validateDetails(String name, String mnumber) throws WalletException {
		boolean output = false;
		if (name.trim().matches("^[a-zA-Z]{1,15}$")) {
			if (mnumber.matches("[0-9]") || mnumber.length() == 10) {
				output = true;
			} else {

				throw new WalletException(IWalletException.ERROR1);
			}
		} else {
			throw new WalletException(IWalletException.ERROR1);
		}

		return output;
	}

	public boolean validateRechargeAmount(String mobnum, BigDecimal amount2) throws WalletException {
		boolean output = false;
		Customer customerinfo = dao.findOne(mobnum);
		BigDecimal amount = customerinfo.getWalletBalance();
		if (amount2.compareTo(new BigDecimal(0)) < 0 || amount2.compareTo(amount) == -1
				|| amount2.compareTo(amount) == 0) {
			output = true;
		} else {
			throw new WalletException(IWalletException.ERROR2);
		}
		return output;
	}

	public List<String> printTransactionDetails(String mobnum) throws WalletException {
		return dao.printTransactionsDao(mobnum);
	}
}
